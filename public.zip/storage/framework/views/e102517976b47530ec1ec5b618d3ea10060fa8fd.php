

<?php $__env->startSection('content'); ?>

<div class="uk-container uk-container-xlarge uk-margin-medium-top uk-margin-medium-bottom">
    <h1 class="uk-margin-medium-bottom">Edit Produk</h1>
    <?php if(session('success')): ?>
        <div class="uk-alert-success" uk-alert>
            <a class="uk-alert-close" uk-close></a>
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>
    <div class="uk-margin-large-top uk-container uk-container-small">
        <form method="POST" action="<?php echo e(url('produks/'.$produk->id_produk)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <fieldset class="uk-fieldset">

                <legend class="uk-legend">Edit Produk</legend>

                <div class="uk-margin">
                    <label for="nama">Nama Produk</label>
                    <input name="nama" class="uk-input" type="text" placeholder="Nama Produk" required value="<?php echo e($produk->nama); ?>">
                </div>
                <div class="uk-margin">
                    <label class="uk-form-label" for="form-horizontal-select">Kopi / Susu</label>
                    <div class="uk-form-controls">
                        <select class="uk-select" name="jenis" id="form-horizontal-select" required>
                            <?php if($produk->jenis == 1): ?>
                                <option value="1">Kopi - kopian</option>
                                <option value="2">Susu - susuan</option>
                            <?php else: ?>
                            <option value="2">Susu - susuan</option>
                            <option value="1">Kopi - kopian</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="uk-margin">
                    <label for="harga">Harga Produk</label>
                    <input name="harga" class="uk-input" type="number" placeholder="Harga Produk" required value="<?php echo e($produk->harga); ?>">
                </div>
                <div class="uk-margin" uk-margin>
                    <label for="upload">Upload Gambar</label><br>
                    <img src="<?php echo e(url('product_img/'.$produk->img_path)); ?>" alt="" style="width: 400px"><br>
                    <div uk-form-custom="target: true">
                        
                        <input type="file" name="file">
                        <input class="uk-input uk-form-width-medium" type="text" placeholder="Ganti gambar" disabled>
                    </div>
                    
                </div>

                <input type="submit" class="uk-button uk-button-primary" value="Submit" style="width: 100%">
            </fieldset>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pakdhejj\resources\views/admin/edit.blade.php ENDPATH**/ ?>