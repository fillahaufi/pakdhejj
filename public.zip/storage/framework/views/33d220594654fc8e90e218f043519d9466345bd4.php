<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>P. Dhe JJ Coffee</title>

    <link rel="shortcut icon" href="<?php echo e(url('/img/logo.png')); ?>" type="image/x-icon">
    
    
    <!-- UIkit CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.7.4/dist/css/uikit.min.css" />
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    
    <!-- UIkit JS -->
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.7.4/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.7.4/dist/js/uikit-icons.min.js"></script>    
    
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/editgui.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?> ">
    
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal8d8bebdc657431257f66d7ad8ae3092afb9d9fb9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Adminnav::class, []); ?>
<?php $component->withName('Adminnav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal8d8bebdc657431257f66d7ad8ae3092afb9d9fb9)): ?>
<?php $component = $__componentOriginal8d8bebdc657431257f66d7ad8ae3092afb9d9fb9; ?>
<?php unset($__componentOriginal8d8bebdc657431257f66d7ad8ae3092afb9d9fb9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
    
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\pakdhejj\resources\views/admin/adminlayout.blade.php ENDPATH**/ ?>