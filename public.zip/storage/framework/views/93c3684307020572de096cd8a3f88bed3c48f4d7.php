

<?php $__env->startSection('content'); ?>

<div class="uk-container uk-container-xlarge uk-margin-medium-top uk-margin-medium-bottom">
    <h1 class="uk-margin-medium-bottom">Penjualan</h1>
    <?php if(session('success')): ?>
        <div class="uk-alert-success" uk-alert>
            <a class="uk-alert-close" uk-close></a>
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>
    <div class="" style="height: -webkit-fill-available">
        <div class="uk-card uk-card-secondary uk-card-hover uk-card-body uk-light uk-margin-small" style="height: 100%">
            
            <div class="uk-overflow-auto" style="height: 400px;">
                <table class="uk-table uk-table-small uk-table-divider uk-table-justify uk-table-middle">
                    <thead>
                        <tr>
                            <th>Atas Nama</th>
                            <th>Timestamp</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($nselling > 0): ?>
                            <?php $__currentLoopData = $sellingnow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($selling->atas_nama); ?></td>
                                    <td><?php echo e($selling->created_at); ?></td>
                                    <?php if($selling->isdone == 0): ?>
                                        <td>Menunggu konfirmasi</td>
                                    <?php else: ?>
                                        <td class="text-primary">Terkonfirmasi</td>
                                    <?php endif; ?>
                                    <td>Rp <span><?php echo e($selling->total_harga); ?></span></td>
                                    <td>
                                        <button class="uk-button uk-button-default" type="button" href="#modal-overflow-<?php echo e($selling->id_nota); ?>" uk-toggle>Lihat Pesanan</button>
                                        
                                        
                                        

                                        <div id="modal-overflow-<?php echo e($selling->id_nota); ?>" uk-modal>
                                            <div class="uk-modal-dialog">

                                                <button class="uk-modal-close-default" type="button" uk-close></button>

                                                <div class="uk-modal-header">
                                                    <h2 class="uk-modal-title"><?php echo e($selling->atas_nama); ?></h2>
                                                    <h5>Nomor Meja : <?php echo e($selling->no_meja); ?></h5>
                                                </div>

                                                <div class="uk-modal-body" uk-overflow-auto>
                                                    <div class="uk-overflow-auto" style="height: 400px;">
                                                        <table class="uk-table uk-table-small uk-table-divider uk-table-justify uk-table-middle">
                                                            <thead>
                                                                <tr>
                                                                    <th>Nama Produk</th>
                                                                    
                                                                    <th>Jumlah</th>
                                                                    <th>Harga</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php for($i = 0; $i < count($produkbought); $i++): ?>
                                                                    <?php for($j = 0; $j < $produkbought[$i]
                                                                        ->where('nota_id', '=', $selling->id_nota)
                                                                        ->count(); $j++): ?>
                                                                        <tr>
                                                                            <td><?php echo e($produkbought[$i][$j]->nama); ?></td>
                                                                            
                                                                            <td><?php echo e($produkbought[$i][$j]->jumlah); ?></td>
                                                                            <td>Rp <span><?php echo e($produkbought[$i][$j]->harga); ?></span></td>
                                                                        </tr>
                                                                    <?php endfor; ?>
                                                                <?php endfor; ?>
                                                                
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                
                                                <div class="uk-modal-footer uk-text-left">
                                                    <div>TOTAL : Rp <span><?php echo e($selling->total_harga); ?></span></div>
                                                </div>

                                                <div class="uk-modal-footer uk-text-right uk-flex" style="margin-left: auto; width: fit-content">
                                                    
                                                    
                                                    <form action="<?php echo e(url('admin/selling/'.$selling->id_nota.'/dec')); ?>" method="PUT">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="uk-button uk-button-danger" type="submit">Batalkan Pesanan</button>
                                                    </form>
                                                    <form action="<?php echo e(url('admin/selling/'.$selling->id_nota.'/acc')); ?>" method="PUT">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="uk-button uk-button-primary" type="submit">Terima Pesanan</button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p>Tidak ada pemesanan</p>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="uk-container uk-container small uk-margin-large-top" style="height: -webkit-fill-available">
        <h3>Riwayat Pemesanan</h3>
        <div class="uk-card uk-card-secondary uk-card-hover uk-card-body uk-light uk-margin-small" style="height: 100%">
            
            <div class="uk-overflow-auto" style="height: 400px;">
                <table class="uk-table uk-table-small uk-table-divider uk-table-justify uk-table-middle">
                    <thead>
                        <tr>
                            <th>Atas Nama</th>
                            <th>Timestamp</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sellinghis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($selling->atas_nama); ?></td>
                                <td><?php echo e($selling->updated_at); ?></td>
                                <?php if($selling->isdone == 1): ?>
                                    <td class="text-primary">Berhasil</td>
                                <?php else: ?>
                                    <td class="text-danger">Dibatalkan</td>
                                <?php endif; ?>
                                <td>Rp <span><?php echo e($selling->total_harga); ?></span></td>
                                <td>
                                    <button class="uk-button uk-button-default" type="button" href="#modal-overflow2-<?php echo e($selling->id_nota); ?>" uk-toggle>Lihat Pesanan</button>
                                    
                                    
                                    <div id="modal-overflow2-<?php echo e($selling->id_nota); ?>" uk-modal>
                                        <div class="uk-modal-dialog">

                                            <button class="uk-modal-close-default" type="button" uk-close></button>

                                            <div class="uk-modal-header">
                                                <h2 class="uk-modal-title"><?php echo e($selling->atas_nama); ?></h2>
                                                <h5>Nomor Meja : <?php echo e($selling->no_meja); ?></h5>
                                            </div>

                                            <div class="uk-modal-body" uk-overflow-auto>
                                                <div class="uk-overflow-auto" style="height: 400px;">
                                                    <table class="uk-table uk-table-small uk-table-divider uk-table-justify uk-table-middle">
                                                        <thead>
                                                            <tr>
                                                                <th>Nama Produk</th>
                                                                
                                                                <th>Jumlah</th>
                                                                <th>Harga</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php for($i = 0; $i < count($produkbought); $i++): ?>
                                                                <?php for($j = 0; $j < $produkbought[$i]
                                                                    ->where('nota_id', '=', $selling->id_nota)
                                                                    ->count(); $j++): ?>
                                                                    <tr>
                                                                        <td><?php echo e($produkbought[$i][$j]->nama); ?></td>
                                                                        
                                                                        <td><?php echo e($produkbought[$i][$j]->jumlah); ?></td>
                                                                        <td>Rp <span><?php echo e($produkbought[$i][$j]->harga); ?></span></td>
                                                                    </tr>
                                                                <?php endfor; ?>
                                                            <?php endfor; ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            
                                            <div class="uk-modal-footer uk-text-left">
                                                <div>TOTAL : Rp <span><?php echo e($selling->total_harga); ?></span></div>
                                            </div>

                                            <div class="uk-modal-footer uk-text-right">
                                                <button class="uk-button uk-button-default uk-modal-close" type="button">Tutup</button>
                                                
                                            </div>

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="uk-text-center">
            <h4>Total Pendapatan : </h4>
            <h2 class="uk-text-primary">Rp <span><?php echo e($sumselling); ?></span></h2>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pakdhejj\resources\views/admin/selling.blade.php ENDPATH**/ ?>